---
pneuma_id: 91de476a0f5a
slug: hybrid-retrieval
type: experiment
---

# EXP-014 · 混合检索

- 实验比较纯向量召回与 BM25 + 向量的 RRF 融合。[cite: faf8c31008a040caa3417a332b2ff9b5 ¶0] <!-- c:8e78019b -->
- 24 条合成任务中融合方案减少了专有名词漏召回；结果只代表内部合成数据。[cite: faf8c31008a040caa3417a332b2ff9b5 ¶1] <!-- c:feeea7b0 -->
- 下一轮必须固定数据集版本，并把失败样本与查询改写分开记录。[cite: faf8c31008a040caa3417a332b2ff9b5 ¶2] <!-- c:136d4183 -->
