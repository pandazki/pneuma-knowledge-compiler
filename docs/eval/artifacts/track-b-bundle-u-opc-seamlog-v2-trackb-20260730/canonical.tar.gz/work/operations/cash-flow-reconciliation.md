---
doc_id: 68f437d5f4c9
slug: cash-flow-reconciliation
title: Cash-flow reconciliation
type: operation
---

## Purpose and evidence boundary

The cash-flow draft is a work surface for placing observed materials together, not a basis for concluding the balance: each line first records the evidence location and then the missing original or confirmation; receipts, work-hour records and incurred repair costs do not by themselves prove payment, settlement notification or a future expense. The draft avoids counting the same matter in multiple folders. [cite: 016c3a0b00677fd2d26b05e303caae4c ¶0] <!-- c:d92abc66 -->

The draft keeps seen items, items awaiting reconciliation and items not yet received separate so a reviewer can see which class lacks evidence; it does not estimate runway or predict when customer procurement or invoicing will occur. [cite: 5d86ebd9b9ed55bd11059856fc06fba3 ¶1] <!-- c:ae12147c -->

## Missing evidence and review

【forming】2026-04-20，林舟确认将遗漏的已发生支出单独标注并保留补入日期与来源；等待中的客户事项不计入可用余额，采购方未回复仅表示尚无可确认的收款安排，不能据此安排下一步工作。林舟拟以两份窄范围选项讨论价格，但暂不发送正式价格或创建对外单据；账表本轮仅用于判断能否继续承担固定成本，并保留继续推进时会真实占用的支持时间，不把它改写成客户已同意购买的内容。[cite: 973f691ebe618e32100bb1ea96e7dd5f ¶0-1] <!-- c:a59d877b -->

【forming】The draft describes 林舟 as recording only material with a traceable location and 贾宁 as checking whether each status has a reason, but the source provides no provenance for these attributions; their roles therefore remain subject to confirmation. [cite: 5d86ebd9b9ed55bd11059856fc06fba3 ¶0] <!-- c:7f09f983 -->

【forming】“开票资料工作本”仍只是来源核对页，不是发票草稿或付款请求：当前可引用的仍是2026-04-22发出的报价版本，核对页只登记保存位置、版本标记和保管人，不重算金额，也不把报价提议改写为已获准事项。内部转交仅表示可查阅来源，不构成报价接受、付款获准或长期合同；现金表继续将这笔可能性保留在未收到一栏，等待[云麓](../../memory/topics/yunlu.md)侧吴岚带回具体字段或补件问题。[cite: 1261d80d32e2a3637d156f226075ed55 ¶0-1] <!-- c:1fe73836 -->

【forming】2026-04-28，林舟撤回了将“本周核对”解释为周五前付款日的假设：吴岚转述的是项目接口人的内部查看状态，而非付款经办人的答复；付款预计日、付款责任人、队列位置及“正在付款流程中”均未知，因此外部款项不计入可用余额，也不与假期中的云服务扣费排列成已确认的一进一出。2026-04-29的后续邮件进一步固定了核对路径：问题先留在项目接口人处，不直接联系付款经办人；在联系人和核对入口确定前，不把“需要补材料”改写成付款流程状态。该路径与[云麓](../../memory/topics/yunlu.md)侧的联系人缺口保持一致。[cite: 10b66a97a7e1d6e8b2f094f369dbb9f9 ¶0-4] [cite: 10b66a97a7e1d6e8b2f094f369dbb9f9 ¶6-7] [cite: 10b66a97a7e1d6e8b2f094f369dbb9f9 ¶10-11] [cite: 518c12d0b6f2e03167154364618b61ee ¶0-1] <!-- c:e2e4ad44 -->

【firm】林舟于2026-04-29只按既定核对路径处理：检查是否出现新的原话、来源人和时间；若没有变化，只登记“查过”，不把转述升级为“快了”。本轮邮件确认，问题先留在项目接口人处，不直接联系付款经办人；联系人尚未确定时不把该状态写成拒绝或付款流程进展。现金动作仅按他自己能够暂停的支出处理，其他支出暂不作决定。[cite: 10b66a97a7e1d6e8b2f094f369dbb9f9 ¶8-10] [cite: 518c12d0b6f2e03167154364618b61ee ¶0-1] <!-- c:c676ba83 -->

【firm】可用余额只按“当前账户余额减去已知必付项”计算；没有可排期日期的外部待收不进入公式，取消订阅只表示未来支出减少，不能提前记作账户增加。该现金口径与[订阅清理](subscription-cleanup.md)的独立支出状态保持一致。[cite: 48201cc671e197458adf9cf91ef7c7e5 ¶0-2] <!-- c:8769c47a -->

【forming】材料记录的操作者将临时缓冲限定给吃饭、交通和基础服务，不补功能预算；可延后的支出须在动作栏留下负责人和截止时间，没有动作的风险保持原样。原材料未提供发生日，相关相对时间保持未确认。[cite: 48201cc671e197458adf9cf91ef7c7e5 ¶4] [cite: 48201cc671e197458adf9cf91ef7c7e5 ¶8] <!-- c:86e7a240 -->
