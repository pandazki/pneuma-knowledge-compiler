---
doc_id: b93ced5abee0
slug: household-rice-subscription
type: operation
---

## Current state

The request to pause only the next rice delivery was not completed: the subscription support team could not verify the delivery building number, so the next delivery remains scheduled as normal until verification succeeds. [cite: 15b6184e3ee0dc9552cc63dee89e96fc ¶0-2] <!-- c:c87796b3 -->

To complete the one-delivery pause, 林舟 can either reply with the building number shown on the order page or send the request from the email address originally used to register the subscription; the verification deadline is Wednesday noon, 2026-03-11. [cite: 15b6184e3ee0dc9552cc63dee89e96fc ¶2] <!-- c:4e898d63 -->
