---
doc_id: 91e587bc2d4d
slug: seamlog
title: Seamlog
type: product
---

## Current state
Seamlog remains a working label and exploratory draft rather than an established project commitment; the cross-project overview is being kept as a draft and no development time has been allocated to it. [cite: 4b477efe39cf09709722a90a5d7b2717 ¶0] [cite: 4b477efe39cf09709722a90a5d7b2717 ¶6-7] [cite: 4b477efe39cf09709722a90a5d7b2717 ¶14] <!-- c:8340bd70 -->

A seed walkthrough surfaced two display defects worth tracking in the page: a missing position on the second card was masked by the layout pulling up the next row, while the third card’s missing reason caused its column to be hidden. [cite: 9fc85a649a22ed6cf99382391afd3f9b ¶0] <!-- c:14058066 -->

【loose】The seed walkthrough record limits the current pass to display issues, keeps the screenshot in a local draft rather than sending it, labels fictional costs beside the seed file, and defers connecting the findings to page code until “Saturday” (relative timing unconfirmed); it also records no fourth card and no additions from oral remarks. [cite: 9fc85a649a22ed6cf99382391afd3f9b ¶0-1] <!-- c:d10d0c9a -->

【firm】Seamlog 的首日材料状态已由入口核对推进到[演示材料接收边界](../operations/demo-material-intake.md)所记录的“已进入只读观察”；这仍不构成资料验证或质量结论，后续判断必须回到各副本的原入口和具体条目。[cite: b4defadc72748e2ef90f7e37a6d60f51 ¶0-7] <!-- c:1c18dee3 -->

【forming】Seamlog 当前的消息重复样本、其未决分类及“不合并或删除”的处理边界，统一记录在[演示材料接收边界](../operations/demo-material-intake.md)（见 c:9715400e）；该观察尚未支持与录制跨日问题共享根因。[cite: c:9715400e] <!-- c:ed94c3f6 -->

2026-04-15，Seamlog 当前受限真实变更验证的执行边界与暂停范围见[演示材料接收边界](../operations/demo-material-intake.md)。[cite: e31c0ce84330c3fc727a8832b1d15a65 ¶1] <!-- c:7c5e0d65 -->

【forming】当前两条演示开场路线及其误读成本检查，详见[演示材料接收边界](../operations/demo-material-intake.md)；该准备材料尚未产生最终入口或产品方向决定。[cite: 55d746bbea4c1c0c2c330d8a79985eff ¶0] [cite: 55d746bbea4c1c0c2c330d8a79985eff ¶3] <!-- c:0c2161a6 -->

【firm】2026-04-29，林舟将周报入口和生成路线移出主分支，同时保留原始记录、来源位置和人工确认信息；页面命名仍未定，因此这次调整不应被表述为周报功能已完成或已改名。[cite: d4dfa4a5d28356f5925d929914fbb977 ¶0] <!-- c:a806fa14 -->

【firm】2026-04-29，Seamlog 的来源回查路径已在两条旧记录上复核通过：深链接可直接回到原句，并在旁边显示范围与确认人；导出仍从记录页发起。旧缩略图导致空壳页面的问题已定位为本地缓存导航项，清缓存并重跑后不再复现；贾宁将空缓存、旧链接和导出文件名列入测试记录。[cite: d4dfa4a5d28356f5925d929914fbb977 ¶1-4] [cite: d4dfa4a5d28356f5925d929914fbb977 ¶9] <!-- c:e6d20a47 -->

【firm】2026-04-29，林舟决定将无人回复的记录标为“未答复”，不并入“待处理”；状态命名仍留待后续决定。导出文件名由 `weekly-summary` 改为带记录日期的 `records`，但文件内容和来源标识保持不变，并以两条旧记录继续复测。[cite: d4dfa4a5d28356f5925d929914fbb977 ¶5-8] <!-- c:0912610a -->

【firm】2026-05-10，林舟将“首条链完成”与入口动作分开：七个账号中只有两人留下完整首条链记录；账号建立、触达或打开帮助页不再被当作产品成果，首页“已触达”卡片与增长趋势图均不再推进。[cite: 300858bd809f88821ec8c6debb8f233b ¶0] [cite: 300858bd809f88821ec8c6debb8f233b ¶6] [cite: 300858bd809f88821ec8c6debb8f233b ¶12] <!-- c:97712a27 -->

【forming】这批复核把“首条链”的可查要求具体化为同时保留被整理的变更片段、可返回原材料的位置和由人明确保存的当前状态；该判据只用于本批记录，不代表稳定行为模型。未完成者不应被解释为拒绝或最终失败，支持对话中的困惑只能连接到对应记录，不能平均归因给其他账号。[cite: 1dd5809573dbcdfb279746501695e237 ¶0-2] <!-- c:97c10dd6 -->

【firm】林舟将复盘卡片改为预算调整与材料替代两行，不再写总评或另加对称的确认栏；预算行回指原有邮件和现场会，材料替代行回指对应的材料范围与现场答复，并让每行保留各自的“读不明白时回到哪里”的位置。[cite: c5921c1acc3fee56d2bc1638b7629dca ¶0-1] [cite: c5921c1acc3fee56d2bc1638b7629dca ¶5-7] <!-- c:88b6ad05 -->

【firm】2026-05-18，材料替代链获得了针对本次记录范围的现场状态确认；Seamlog 的两条链仍须分别展示各自的来源、状态和确认依据，第二条链的状态确认不替第一条预算链补内容，也不把定位问题、删除演练或未解决的附录/尾款/延长事项并入完成结论。运行细节见[演示材料接入与记录完整性](../operations/demo-material-intake.md)。[cite: bd160e9c3df4504db008174f8666438d ¶1-8] <!-- c:b6df1914 -->

## Product problem and direction
【forming】The product direction is to distinguish a proposal from an accepted decision, preserve who introduced a statement into the record, and avoid treating every number as a confirmed scope or budget change. [cite: 63fb9ae20dc108053f9a8f7e4a276ea3 ¶5] <!-- c:ec7f5296 -->

【loose】Chen Fang said an existing weekly report is not where he would start when asked why something changed, although a lightweight everyday scan might still be useful; this feedback does not validate a weekly overview as the retrieval path. [cite: 201ca80e9672e98c501241933f8a26cd ¶8-9] <!-- c:a9b26add -->

A record-finding episode showed that a user may narrow a meeting by attendee and date, search an imperfect transcript using remembered fragments, and then return to the audio; transcript errors, broad segment headings and loss of playback position left the user listening through a long agenda. This is evidence for traceable, time-localised retrieval rather than a polished weekly overview. [cite: dfa1f599a23dbbe97958ee64b47826aa ¶2-5] [cite: dfa1f599a23dbbe97958ee64b47826aa ¶9-12] <!-- c:2e2ed34e -->

【forming】For the next discovery session, do not begin by showing a prototype; ask the participant to recount the most recent episode in which they were asked to explain or change something, starting before any window was open, and follow the first remembered search term, abandoned windows, help sought, and what remained missing at the stopping point. [cite: 5abcb656e143aa855cda0dea3682896f ¶0-1] <!-- c:7065c73d -->

【forming】在 2026-03-13 的范围讨论中，林舟把此前“证据链优先”的工作假设推进为本轮试点的范围决定：先验证争议时回到原话和后来的判断，再判断概览是否仍有价值；自动周报不进本轮目标，总览与任务板暂停。[cite: 87c32585b077594c25e6199133cd5c4f ¶2] [cite: 87c32585b077594c25e6199133cd5c4f ¶4] [cite: 87c32585b077594c25e6199133cd5c4f ¶8] <!-- c:44755abb -->

【forming】本轮范围草稿把目标暂定为：让被选中的一小段沟通能够回到原话，而不是替整间工作室重排工作；这仍是待回应问题单验证的方向，不是已获准的试点范围。[cite: bd1d2a5a84145d6f4fcb22cb23c8d769 ¶1] <!-- c:bb13560e -->

2026-05-09，陈放对当前长教程的反馈是：真实项目中临时核对一条变更的人不会先读完教程，而会先找眼前要做的动作、确认原句不会被覆盖，并核对状态是谁留下的；人物或权限不清时应直接显示缺口，“不是自动判断”也必须在第一眼出现。多人意见、替代版本和补充理由的可见范围可按情形展开。该反馈只回答长教程是否适合现场使用，不是最终流程、客户结果或第二条材料链的验收结论。[cite: 025f3b85b93da3ab3723767a8a4a3494 ¶0-1] <!-- c:1e409add -->

【firm】第一条链导出的阅读层修订仅改变显示词、阅读顺序和跳转标签：回放从页面顶部的“预算调整记录”和范围说明开始，先辨认对象，再依次理解最初提出的邮件、说明现场范围的会议位置和当前状态三个入口，最后从任一入口返回来源；预算影响放在对象说明旁，责任人只随状态入口出现。状态显示“待确认”并附留存人和记录时间，不替采购完成确认或批准。原记录、地址、来源日期和当前状态均不被排版改写，不把生成时间混成事实发生时间，也不把当前状态倒填到旧邮件；本试点页面另说明只处理预算变更和材料替代，不含供应商审批。该修订不替第二条材料链建立验收或开始时限。[cite: 423ecaec8fed7f6cf61b80422b7695f5 ¶0-2] <!-- c:abf97da6 -->

【firm】第一条链导出的阅读层修订仅改变显示词、阅读顺序和跳转标签：首列写作“预算调整记录”，三个入口分别指向最初提出的邮件、说明现场范围的会议位置和当前状态；预算影响放在对象说明旁，责任人只随状态入口出现。原记录、地址、来源日期和当前状态均不被排版改写，不把生成时间混成事实发生时间，也不把当前状态倒填到旧邮件；本试点页面另说明只处理预算变更和材料替代，不含供应商审批。该修订不替第二条材料链建立验收或开始时限。[cite: 420c23e2ea9a34cd2490d53fa8570be8 ¶0-3] [cite: c:270160f1] <!-- c:518af8a0 -->

【firm】在[云麓](../../memory/topics/yunlu.md)这次复盘中，林舟将两条记录链“可读”限定为证明这一窄的回查位置有用：Seamlog 不替代现有项目表、不负责派工，也不把采购等待转成产品内的绿色状态；复盘标题因此改为“两条记录的阅读回看”，不再暗示它管理其他工作。[cite: 78d351e415c740512274372fe704d0a2 ¶1-3] [cite: 78d351e415c740512274372fe704d0a2 ¶10] <!-- c:270e38a5 -->

## Initial scope decision
【forming】The unresolved validation question is whether Seamlog saves users time during a concrete record-finding episode or merely turns the owner's curiosity into a page; discovery questions should ask what they first searched for, what remained missing, and which step counts as confirmed, rather than asking what dashboard they want. The answers should guide what to retain in the prototype, while proposal, confirmation and non-response remain distinct states. [cite: 4b477efe39cf09709722a90a5d7b2717 ¶8-13] <!-- c:d5c7b2aa -->

【firm】For early discovery, show only three fictional dialogue fragments—a proposed material change, a price-difference question, and an explicit “wait”—with an intentional blank in each; do not use old consultation screenshots or interpret willingness to review the mock-up as permission to provide real project data. [cite: 55b89af738b93189632f2164e429bec8 ¶6] <!-- c:97fa7161 -->

【forming】Discovery language should avoid promising “automatic organisation of all communication”, a “complete project view”, or “no need to disturb anyone”; these claims are not yet supported before learning how a frontline user describes the problem. [cite: 55b89af738b93189632f2164e429bec8 ¶5] <!-- c:45529467 -->

【firm】2026-04-26，林舟撤下原定次日演示的讲解入口，不沿用自动周报作为第一屏或旧讲解顺序；会议时间暂留空，也不借此替产品方向下结论。旧页仍留在开发环境，撤下讲解不等于停用该功能，待另行决定旧页去留。[cite: 564abf349a6fe6a6c7bd3c008c9354d4 ¶0-2] <!-- c:07bcb2ab -->

【forming】The broad wording “all projects can use” was rejected from the scope draft because it had no interview basis and would implicitly include people, tasks and progress; it was marked as imagination rather than replaced with another definite scope. [cite: 59f87079693f5501e6fe10970e4adde1 ¶1] <!-- c:e20eb7bb -->

【forming】The cross-project board is not a valid substitute for defining the core change-record relationship: 贾宁 challenged expanding into projects, tasks, people and progress before establishing why a change is retained and where it belongs; 林舟 could not identify an independently evidenced board column and moved the page back to the sketch area without continuing interaction. The board therefore remains a questioned, unvalidated alternative rather than accepted scope or a product direction. [cite: f0812fccbceaf7709cc4012d82fdbb37 ¶0-5] <!-- c:a96533e6 -->

【firm】2026-03-13，林舟将本轮试点的范围决定为“证据链优先”：只验证发生争议时能否沿一条记录找回原话和后来的判断；自动周报移出试点目标，总览与任务板暂停，先做能容纳原文、出现时刻、状态和确认者四项的纸面卡。该决定的依据是两次一线反馈都把争议时的来源回查置于概览之前；状态表达、确认资格和数据入口仍未决，且这段范围核对不等于已获准开始或开放数据。[cite: 87c32585b077594c25e6199133cd5c4f ¶2] [cite: 87c32585b077594c25e6199133cd5c4f ¶4] [cite: 87c32585b077594c25e6199133cd5c4f ¶6-9] <!-- c:ab3cdeb3 -->

【firm】本轮只使用虚构短句制作纸面卡，不把吴岚对范围文字的核对回复贴到样例中充当确认者；真实数据、具体对象、角色和访问方式均未开放，后续是否继续另行决定。[cite: 87c32585b077594c25e6199133cd5c4f ¶9-11] 相关演示材料边界见[演示材料接收边界](../operations/demo-material-intake.md)。 <!-- c:e7fff0a5 -->

【firm】本轮暂不把任务管理纳入范围：陈放已有现场排期，另建待办不会补回缺失附件或变更证据，且会增加需要维护和解释更新来源的表；问题单中的任务仍标为“不替代现有排期”。若以后有人提出该需求，应先说明它与变更回查的直接关系。[cite: d6a4fff3e64dff096fb574dbf7e9d7c4 ¶2-3] [cite: d6a4fff3e64dff096fb574dbf7e9d7c4 ¶9] <!-- c:9898adcb -->

【forming】报价生成与审批流仍只列为待问而非默认功能：问题单只保留“谁会需要、谁能决定、会碰到哪些材料”等问题，不把“可能有用”改成“这轮要做”，也不从一段沟通扩展到生成报价或替代客户审批。[cite: d6a4fff3e64dff096fb574dbf7e9d7c4 ¶0-3] [cite: d6a4fff3e64dff096fb574dbf7e9d7c4 ¶9] <!-- c:20688ec5 -->

【firm】截至 2026-03-14，林舟把范围核对收窄为四问：验证哪件变更、谁提供材料、谁查看结果、谁始终排除；参与者栏留空，等待各自确认，不向任何目录取数据，也不把这份记录命名为试点。问题单的结论只是问题更窄，不是试点开始；任务、报价和审批仍在待排除或待问。[cite: d6a4fff3e64dff096fb574dbf7e9d7c4 ¶6] [cite: d6a4fff3e64dff096fb574dbf7e9d7c4 ¶9] <!-- c:f66e3b0d -->

【firm】2026-03-20，当前试点验收至少包含“项目范围内导出”和“按项目移除”两项：导出须观察选定项目能否给出记录、来源位置和当前状态，并检查是否出现范围外条目；移除须观察能否提出并复核一次项目范围的移除，以及请求与完成说明是否对得上。这些是验收观察项，不是已经完成的演练或通过结论。本轮问题结构进一步明确：导出接收者、检查人和排除条目仍待项目侧填写；移除须先指向具体项目和材料范围，并保留提出人、需通知者、归属不明时的处理及完成回告；若导出越界或移除无法核对到项目，仍记为未完成并回到问题单。[cite: 39db3613d8d117d4cf5962237000ad2e ¶2] [cite: 39db3613d8d117d4cf5962237000ad2e ¶8] [cite: 39db3613d8d117d4cf5962237000ad2e ¶10] [cite: 370a3b5da2d4dead6d4c76d14f427625 ¶0-2] <!-- c:dabda012 -->

【firm】2026-03-20，林舟决定本轮只产出验收项和采购问卷，不以今天的讨论启动目录、导入或实际演练；执行人、材料、起算日、移除确认人及其他边界仍留空，待边界清单有负责人后再讨论观察。[cite: 39db3613d8d117d4cf5962237000ad2e ¶5] [cite: 39db3613d8d117d4cf5962237000ad2e ¶8] [cite: 39db3613d8d117d4cf5962237000ad2e ¶11] <!-- c:8b5df004 -->

【forming】2026-03-20，采购问卷骨架把材料范围、使用者、导出接收者、删除请求、范围判断、完成回告和各自的答复归口拆成独立问题格；空格可答“不适用”或“待定”，未答不构成许可，也不把“答复归口”解释为最终决策人或删除负责人。本轮问题结构说明这些格子只是待填写的边界信息：孙秋提供了材料范围、查看者、导出接收、移除请求和核对说明等结构，但模板没有替任何人指定角色，也不授予导入许可。[cite: 39db3613d8d117d4cf5962237000ad2e ¶6] [cite: 39db3613d8d117d4cf5962237000ad2e ¶9] [cite: 39db3613d8d117d4cf5962237000ad2e ¶12-13] [cite: 370a3b5da2d4dead6d4c76d14f427625 ¶3] <!-- c:f1ff44e1 -->

【firm】2026-03-29，林舟与参与者确认本轮试点于2026-03-30开始、持续两周；首日只检查两条已列变更能否各自回到原处、提议/确认/未答状态是否分开，以及面对真实删除请求时能否说明可执行路径。其余功能和历史整理不在本轮承诺内；首日观察只记录已看到的内容和缺口，不写总分或完整说明。[cite: a8bc97dfc39915bbbcdd86852176f93d ¶0-1] [cite: a8bc97dfc39915bbbcdd86852176f93d ¶3-5] [cite: a8bc97dfc39915bbbcdd86852176f93d ¶10] <!-- c:58b964ea -->

【forming】首日观察表将原“结果”列改为“页面回应”和“观察人”，并将会议观看页、项目沟通、邮件归集和每日笔记分别保留为入口行；表格只记录入口是否被打开，不把页面访问写成内容正确或导入结论。[cite: cda0d97f2e3c4bcac9a053369d5ca7d1 ¶0] <!-- c:eb4ca380 -->

【forming】首日观察表把“下一步”改为可留空的“待问事项”，让页面可打开、文字稿暂不查看和空主题测试件已到达等状态各自保留短说明，而不压成统一的通过标记；次日批次单只复制列名和本次版本时间，首日不预填联系人、回执或导入状态。[cite: cda0d97f2e3c4bcac9a053369d5ca7d1 ¶1] <!-- c:bc5e0ecb -->

【firm】2026-04-18，林舟明确将采购材料与真实变更验证分开：采购阅读包不向陈放转发；若需要陈放选择材料，只发送范围和原位置，不要求他先阅读责任说明，也不让他代为解释采购文字。该边界作为[演示材料接收边界](../operations/demo-material-intake.md)下的验证交接约束继续执行；采购阅读包的意见回传与版本冻结规则见该文档。[cite: 97404ded6bd8dc8108aba0932b84982e ¶0-3] [cite: 97404ded6bd8dc8108aba0932b84982e ¶7-8] <!-- c:c0b9bf9c -->

【forming】这轮尚未完成的邀请工作台把演示反馈重点放在误读原话、状态或旧资料位置，以及能指出证据位置和迁移断点的视角；它仍只是待完成的参与者筛选与邀请准备，不构成已收集反馈或对产品方向的验证。相关邀请准备见[演示材料接收边界](../operations/demo-material-intake.md)。[cite: fae10fa6a75e0761c6f899a3d1eefcd9 ¶0-5] <!-- c:b27d8ba1 -->

【firm】2026-05-05，Seamlog 的待发邀请入口在发出前完成了两类独立链接修复并通过无历史记录窗口复查；主入口未变，说明页与反馈返回目标分别修正。相关邀请准备与复查边界见[演示材料接收边界](../operations/demo-material-intake.md)。[cite: 0eb3beb9bdcbb0b7d214c17318fb7fcd ¶0-1] <!-- c:afd58e1f -->

【forming】2026-05-05，Seamlog 的小范围邀请已按[演示材料接收边界](../operations/demo-material-intake.md)的私密入口和虚构材料规则发出；何明的首轮查看在尚未选定材料时停在第一屏，不能计为完成或产品验证结果。[cite: 4eb48fc5016fce53ec14eb2fe2ee6388 ¶0-1] <!-- c:8fe9429e -->

【forming】本轮第一屏草图对“浏览样例”与“留下判断”的分流、字段预览和后续停表测试，统一记录在[演示材料接收边界](../operations/demo-material-intake.md)；该草图仍未确定真实角色、默认可执行范围或最终状态名称。[cite: 1b8645f383e901b916c8bdf0e2b6d34e ¶0-3] <!-- c:fe476cc2 -->

【firm】2026-05-10，首次成功的可重放定义暂定为：具体材料能够进入记录，留下明确状态，并能点回原处；本轮暂不附加同次会话或时长目标。[cite: 300858bd809f88821ec8c6debb8f233b ¶7] [cite: 300858bd809f88821ec8c6debb8f233b ¶11] <!-- c:b98d21c1 -->

【forming】2026-05-10，林舟把“首屏要求先选整个项目的数据来源”记为待查假设，而非当场改流程；针对后续逐条回放，将并列核对页面要求、使用者手边已有材料和完成首链真正必需的字段，再判断是否应收窄首步输入或先澄清必要字段。索引只登记内部编号、最后可见页面、已发生动作、当事人回复与录屏位置，不把未录到的动作或无文字反馈的原因补入正文；其用途是返回原片段，不把页面停留自动归类为态度或永久结果。[cite: ace5a26dc01838c8bf08ebb72a04f38f ¶0] [cite: ace5a26dc01838c8bf08ebb72a04f38f ¶3] [cite: 300858bd809f88821ec8c6debb8f233b ¶8-9] [cite: 300858bd809f88821ec8c6debb8f233b ¶14] <!-- c:fae1d75f -->

【forming】2026-05-10，后续回放的观察分工暂定为：贾宁核对页面实际索取的字段，林舟核对使用者当时持有的材料；遇到同一画面却走出不同动作时并列保留，不先替差异寻找共同解释。回放前还需确认录屏是否来自同一版本，并检查最后画面能否与支持回复相互定位；若回复与画面不一致，两者并列保留并标为待核，不能用较晚材料覆盖较早材料，也不能让没有回放证据的猜测进入索引正文。[cite: ace5a26dc01838c8bf08ebb72a04f38f ¶2] [cite: 300858bd809f88821ec8c6debb8f233b ¶14] <!-- c:bc2d0425 -->

【forming】Seamlog 的范围请求草图新增了预览、单独确认、可撤回范围与请求版本等边界；具体规则及仍待工程核对的撤回/时间范围问题见[演示材料接收边界](../operations/demo-material-intake.md)。[cite: ae06ede726ac0d430040442905e3397c ¶0-3] <!-- c:40bb72f0 -->

【forming】Seamlog 的首步单段变更输入约定要求：只接收使用者选中的原文并保留原始换行与起止位置，不以摘要覆盖正文；正文为空时阻止提交，只有标题、人物名或状态词也不视为材料。选区变动后显示首尾各一行，以降低误带无关内容的风险。[cite: a4a47e98001515f926f8ec21b46c38ef ¶0] <!-- c:b99cd43a -->

【forming】Seamlog 的定位信息分为“来源类别”和“回查地址”两格，二者可暂缺但必须记录缺失原因；系统不从邮箱格式、文件后缀或说话人自动猜测类别，提交后保留原值与缺失说明，后补地址通过新修订写入。[cite: a4a47e98001515f926f8ec21b46c38ef ¶1] <!-- c:d3da984e -->

【firm】Seamlog 的首步保存响应只返回片段编号、正文版本、定位字段当前值和修订入口，不启动历史扫描；既有材料集合接入或持续跟随必须另发范围升级请求，并保留原片段编号，以区分首批搬入与后续变化跟随。[cite: a4a47e98001515f926f8ec21b46c38ef ¶2] <!-- c:3b204f05 -->

【forming】Seamlog 的首步输入约定仍有四项待评审：单段长度上限、重复粘贴相同正文时是否提示、缺失原因能否由下一位维护人改写，以及后补定位是否必须保留旧值；这些不预填答案。陈放是否愿意试用尚未询问，测试材料继续使用虚构文本。[cite: a4a47e98001515f926f8ec21b46c38ef ¶3] <!-- c:dfd9a107 -->

【firm】2026-05-11，林舟将首步入口决定为只呈现片段输入，不让多来源全量导入占据入口；该决定来自试验分支中折叠连接器区后输入框独立出现、并以最小输入提交通过的观察，其他能力入口另行设计，不在本次改动中顺手搬迁。[cite: 24995ad298594064d37d98e05f2b504e ¶1-4] <!-- c:7070e3bc -->

【forming】2026-05-11，林舟把提交阻断、空来源回执措辞和默认勾选分别作为独立观察留工单：至少选择来源的校验曾阻断提交且与按钮不在同一处；关闭该校验只用于试验分支，不能视为永久删除；“来源：空”仍需用虚构内容复看措辞，历史同步不得默认勾选，既有材料与后续新增应分别让人选择。[cite: 24995ad298594064d37d98e05f2b504e ¶2-5] [cite: 24995ad298594064d37d98e05f2b504e ¶7-9] <!-- c:4690a0d5 -->

【firm】2026-05-14，林舟把首次成功的停表范围收窄为：从使用者选定一段变更材料并进入导入页开始，到该片段进入链并由使用者明确留下当前状态为止；建项目、选择项目归属、邀请协作者、补背景、阅读全部说明、整理后续材料和建立第二条链均不计入这一路径。预先选择项目归属、邀请协作者和背景说明移到状态已留下之后；页面须明确这是使用者留下判断而非系统自动判定，并保留来源位置。该版的二十分钟是待检验目标，不是已达成结果；删除签字、付款日期、后续确认人及其他链不纳入本次试走。[cite: beb1930fafed6c5474950fb335aeb506 ¶1-3] [cite: beb1930fafed6c5474950fb335aeb506 ¶4-7] [cite: beb1930fafed6c5474950fb335aeb506 ¶8-10] 试走记录与反馈按[演示材料接收边界](../operations/demo-material-intake.md)的受限材料边界执行。 <!-- c:20d4a2d2 -->

【forming】截至2026-05-24，下一周期的继续方向收窄为只服务小型设计团队的变更证据链：先让一条记录回到来源、一次确认和当前状态的原处；项目管理、采购或审批不并入这次延续，也不以[云麓](../../memory/topics/yunlu.md)的邮件作为批准。该方向与待解事项分开保存，仍不是已获批准的试点范围。[cite: 9918a9fdf0772a576f36d101fb17a3b9 ¶0-2] <!-- c:b4880389 -->

【forming】下一周期的新工作卡只问一条记录如何回到来源、确认和状态，并以此检查小型设计团队的变更证据链；若有人要求排程、供应商审批或全项目看板，卡片标记为范围外，等待独立讨论。[cite: 2f2986123304f1fed03e5a277b96af49 ¶3] <!-- c:e229001f -->

## Evidence and modelling constraints
The motivating cases involve incomplete and conflicting records, including unclear confirmation, changed budgets preserved only in screenshots, and different recollections of versions; these are remembered examples rather than reusable customer data. [cite: 63fb9ae20dc108053f9a8f7e4a276ea3 ¶0] [cite: 63fb9ae20dc108053f9a8f7e4a276ea3 ¶10]
A single smooth timeline is inadequate when statements may be opposed, unanswered, or affect different objects; the product needs to retain the statements side by side and make later action and possible withdrawal reviewable rather than replacing them with an inferred conclusion. [cite: 63fb9ae20dc108053f9a8f7e4a276ea3 ¶6] <!-- c:07d530c0 -->

【forming】User interviews should ask what material was already available when the person needed to explain a change and which segment was missing—such as an attachment, speaker identity, message order or outcome—rather than framing the product as remembering everything; the answers should guide what to remove from the next mock-up, not decide the product on the interviewee’s behalf. [cite: 55b89af738b93189632f2164e429bec8 ¶4] <!-- c:c569ed66 -->

【forming】A mock-up review should record only the concrete problem the reviewer actually points out; asking whether someone is willing to look at a mock-up is separate from asking for source data or permission to connect a project. Until they reply, record the state as unanswered and do not pre-register project names, colleagues or old material. [cite: 4b477efe39cf09709722a90a5d7b2717 ¶4-5] [cite: 4b477efe39cf09709722a90a5d7b2717 ¶14-15] <!-- c:486fc565 -->

【forming】Treat the next account from 吴岚 as a second sample only if she recounts her own path; her statement that she will first ask a coordinator does not establish that the other party is willing, and the current question list remains local. The 3 月 5 日 note likewise leaves the coordinator’s willingness and timing pending confirmation. Do not generalise one account into a team habit. [cite: 5abcb656e143aa855cda0dea3682896f ¶2] [cite: 4335a6318e5ecce173fb858547b74774 ¶1] <!-- c:c82c26be -->

【forming】For the three prompts on materials, costs and delivery dates, capture only the starting point, turn and stopping point; leave conclusions blank, and distinguish a case with a spoken process from cases that have only prompts rather than filling gaps from general knowledge. [cite: 5abcb656e143aa855cda0dea3682896f ¶3] <!-- c:aa788ab2 -->

【forming】A single interview observation found that 吴岚 began by recalling who had attended before touching the search box; the interviewer’s framing of chat as the first step was corrected, and a return to a weekly page did not establish that the page was the obstacle. Treat this as one participant’s path, not a general user pattern. [cite: 4335a6318e5ecce173fb858547b74774 ¶1] <!-- c:5e147ed1 -->

【forming】In the 3 月 5 日 interview notes, case A (a material change) has a complete account of the participant’s search, while case B (a cost question) is only a prompt about checking different locations and case C (a delivery-date dispute) was not discussed; do not reconstruct B or C by imposing A’s sequence. [cite: 4335a6318e5ecce173fb858547b74774 ¶2] <!-- c:8546e5ae -->

【firm】The current card prototype stores only `title`, `date`, `summary` and `sourceKind`; its test cards are fictional, contain no external content, and still navigate to the overview rather than a concrete source position. The current homepage demo likewise retains three fictional cards and keeps the weekly number collapsed, without treating a trial click as evidence that the navigation gap has disappeared. [cite: f4b967bf2ceaca4de409945f3baca7cb ¶2-4] [cite: f4b967bf2ceaca4de409945f3baca7cb ¶8] [cite: f4b967bf2ceaca4de409945f3baca7cb ¶10] [cite: 306ed10bc9dd347f9db2a45f5d3b8ccd ¶0] <!-- c:c1ff3237 -->

【forming】Each source type must retain a minimum concrete location for meetings, messages and documents, while the shared location shape remains undecided. Chen Fang’s review adds that a card should show the speaker’s original wording and a pointer back to its source, with meeting minutes, an individual message and a document passage kept as separate location forms; do not turn a shared page or adjacent statements into mutual proof. [cite: f4b967bf2ceaca4de409945f3baca7cb ¶3-6] [cite: 306ed10bc9dd347f9db2a45f5d3b8ccd ¶3-4] [cite: 201ca80e9672e98c501241933f8a26cd ¶1-7] <!-- c:36697c2e -->

【forming】受限旧项目副本的演示请求及其接收边界记录在[演示材料接收边界](../operations/demo-material-intake.md)；Seamlog 的页面测试应沿用该边界。 [cite: 48990e547e8a6ce74be62e1a34efb4f5 ¶10-13] <!-- c:b98df424 -->

【firm】A retired prompt trial on fictional role-labelled snippets showed that completion-oriented generation invented causes, responsibilities and next steps when the input did not support them, and concealed an empty source location; the resulting generated cards were not retained as showcase examples. The current demo removes four such completion behaviours—auto-writing change reasons, collapsing multiple people into one responsible person, smoothing over gaps, and generating an ending without a source—and retains only verbatim fragments plus empty slots; this removal is in a demonstration copy, not a model-finalisation claim. If this direction is reopened, it requires newly written tests rather than restoring the retired prompts. [cite: 489defc8ae7c2084489b5196da26c036 ¶0-6] [cite: 306ed10bc9dd347f9db2a45f5d3b8ccd ¶1-2] <!-- c:cb82113e -->

A retrieval episode found that the broad term “位置” mixed unrelated candidates; restricting the search to `path:工作/原型 content:sourceKind` returned the 3 月 7 日 review page, and an exact remembered phrase was then used to rule out a same-name draft. This is one observed search path, not evidence that the broad term is generally inadequate. [cite: c2b35a10d773767fa6dfab6a50e10c73 ¶1] <!-- c:ddbd4502 -->

A retrieval episode showed that search can locate candidate fragments but cannot determine who is authorised to confirm them: 林舟 opened the candidate page, read surrounding context, found four object keys and an unresolved question without a field scheme, and treated a “点头” hit from a fictional example as insufficient to identify the confirmer. Chen Fang likewise said that a spoken statement and the responsible person who authorises work may differ, so Seamlog should expose the original wording and source position without inferring authority. The product should not promote search hits into answers or infer authority from them. [cite: c2b35a10d773767fa6dfab6a50e10c73 ¶2-3] [cite: 201ca80e9672e98c501241933f8a26cd ¶3-7] <!-- c:88eb715f -->

A retrieval episode did not preserve an automatic search view because the queries were still changing; fixing the view was judged likely to hide what had been missed. This supports treating saved search views as provisional rather than as a complete account of retrieval coverage. [cite: c2b35a10d773767fa6dfab6a50e10c73 ¶4] <!-- c:39782a95 -->

【firm】陈放此次纠正的不是方案本身，而是林舟把“先换样板”扩大成“整套都换”的范围摘要；因此纠正不等于撤回此前对小范围步骤的同意。Seamlog 必须把原话、林舟的范围概括和后续动作作为不同对象处理，不能因其中一个对象被说“不对”就把三者一起标为撤回；原句仍须可见，摘要的修改也不能覆盖原句。[cite: 6f3b3243311f92b8934d5ad9a39667c3 ¶0-3] [cite: 6f3b3243311f92b8934d5ad9a39667c3 ¶6-8] <!-- c:66dee477 -->

【forming】“变更链”字段目前仍是纸面试写而非可用数据模型：来源片段与发生时刻可暂作候选格，但关系占位、留下判断的人和备注的语义与权限尚未解决；空白不得自动补成结论，原句应继续留在访谈摘录页而不是被运行样例改写。[cite: b4234a5766f13600340a90f7b2490bf0 ¶0-1] <!-- c:1a60cfdc -->

【firm】林舟在第一轮纸面试写中不预填吴岚、陈放或林舟作为“留下判断的人”，不设置默认答案，并把空格视为当前缺口；下一轮若讨论范围，应先验证具体关系，而不是盘点整个项目还缺哪些页面。[cite: b4234a5766f13600340a90f7b2490bf0 ¶3] <!-- c:d91276b7 -->

【forming】本轮把状态语义重新打开，而不是确定“待确认、已确认、已撤回”这三个名称或证明三类已经足够：至少要分别追踪等待哪种判断、哪个对象已有明确答复，以及哪个先前动作是否真的被取消；“收到”“原话已确认”“同意执行”也不能由同一个“确认”状态代替。下一版样例须同时显示对象、说话人和时间，并保留人的解释；是否保留三类及其命名，待冲突样例继续验证。[cite: 6f3b3243311f92b8934d5ad9a39667c3 ¶8-13] [cite: 6f3b3243311f92b8934d5ad9a39667c3 ¶16-17] <!-- c:66687a82 -->

【firm】纸面卡的四项中，原文必须保持不改写，时间指向原文出现的时刻；状态只保留位置而不预造选项，确认者没有依据时留空，不能由发言人自动推定。对于会议时间，林舟进一步决定保留原写法、来源和可见日期，不在缺少明确时区时换算成另一种时间、假定偏移或把未解释记录强行排到最后；解释待完成时只能标记为待解释，不能把排序风险写成已发现的错位。谁有资格修改状态、数据入口以及具体关系仍需后续讨论。[cite: 87c32585b077594c25e6199133cd5c4f ¶5-7] [cite: 6eacc93571f606423a6b09a6f4cc5b0b ¶0-5] [cite: 6eacc93571f606423a6b09a6f4cc5b0b ¶7-9] <!-- c:f82223fb -->

【forming】Seamlog 的相近姓名整理与[演示材料接收边界](../operations/demo-material-intake.md)保持一致：候选不得被提升为身份、发言人或负责人结论，进入会改变其他记录的流程前需要独立保存的人工“不合并”判断。[cite: 78ea1bf2a55d792a108567e4ed8824e0 ¶0-1] <!-- c:62af9558 -->

【forming】Seamlog 的流向草图继续把责任、可见性、核对与移除保留为空间化待答项，而不是把画出的箭头当作已运行流程；相关的接入边界与待答位置记录在[演示材料接收边界](../operations/demo-material-intake.md)。[cite: a08f16db6abe3ec18a5ebc715a3730f6 ¶0-1] [cite: a08f16db6abe3ec18a5ebc715a3730f6 ¶4] [cite: a08f16db6abe3ec18a5ebc715a3730f6 ¶6-7] [cite: a08f16db6abe3ec18a5ebc715a3730f6 ¶9] <!-- c:acb2d39e -->

【forming】采购答复路由卡的草稿结构把每个问题的来源、拟交答人和可退回理由分开，并在转交后保留改派、要求原处位置或暂时无法判断的结果；这支持将答复归口与客户结论、范围判断和状态确认分开，且不要求收件人为他人补答。[cite: 5de764320e119750ecce8ebbd455a018 ¶0-1] <!-- c:65135e81 -->

【firm】2026-03-29，本轮观察记录必须保留观察时间和观察人；同一页面有多个观察人时分别记录各自看到的内容，不压成“团队确认”。录音换房间或文字稿可能听错人名时，先保留带时间的问题，不用自动摘要抹平；页面访问也不能被解读为客户认可，原页面内容不应因疑问而被改写。[cite: a8bc97dfc39915bbbcdd86852176f93d ¶2] [cite: a8bc97dfc39915bbbcdd86852176f93d ¶6] [cite: a8bc97dfc39915bbbcdd86852176f93d ¶8-9] <!-- c:bcd537d7 -->

【forming】2026-04-04，Seamlog 本次局部去重与编辑回放顺序的运行状态见[演示材料接收边界](../operations/demo-material-intake.md)。[cite: 0162f33270c2ff505b0b9f56fd0129d6 ¶2] [cite: 0162f33270c2ff505b0b9f56fd0129d6 ¶6-14] <!-- c:75cffe23 -->

【firm】2026-05-07，Seamlog 首轮邀请统计把“注册”限定为账号建立记录，并按受邀地址去重；周二实际发出 12 份小范围邀请，截至当天 09:30 有 7 位受邀对象留下该记录。该页不据此推断引导、核心任务或产品使用，且未与不存在的上一期比较。[cite: 04ff863d4786cccf2b8941cf7a97c68b ¶2-5] [cite: 04ff863d4786cccf2b8941cf7a97c68b ¶13-16] <!-- c:fa1b9dae -->

【firm】2026-05-07，林舟决定不把“激活”作为未定义的统计栏：注册、开始查看说明和完成一次核心任务必须分开，只有在独立定义出有产品意义且可稳定观察、可记录触发者与时间并可重放的行为后，才另行统计激活。[cite: 04ff863d4786cccf2b8941cf7a97c68b ¶8-9] <!-- c:07c810bb -->

【firm】2026-05-07，林舟决定将反馈表空白单独作为数据完整性检查，不把未作答解释为统一原因或用户态度；检查先确认题目是否出现、是否允许跳过以及提交是否保存，不从现有支持对话推断总体原因。[cite: 04ff863d4786cccf2b8941cf7a97c68b ¶10-13] <!-- c:e8cfa5ea -->

【firm】2026-05-07，林舟放弃用这次同批邀请、三天窗口和单一截至点绘制增长趋势图，保留逐条时间仅供复算；本轮不以该统计回答产品是否已被使用，也不把后续行为、反馈空白或整体支持负担纳入结论。[cite: 04ff863d4786cccf2b8941cf7a97c68b ¶14-17] <!-- c:b6eb0313 -->

【forming】一次虚构卡观察显示，醒目的“已确认”若缺少人物、时刻和来源提示，读者可能把既有记录误读为页面自行得出的结论；后续返工将以只读入口、来源提示和分开的角色/理由问题检验这一呈现缺口，而不把单次观察写成满意度或产品验证结论。详细记录见[演示材料接收边界](../operations/demo-material-intake.md)。[cite: a15187343cdf848be3910858e5915949 ¶1-5] <!-- c:ab65baf9 -->

【forming】最新虚构双卡回读检查及其后续测试边界已记录在[演示材料接收边界](../operations/demo-material-intake.md)（见 c:b98d0ed5 与 c:09de1ee0）；Seamlog 不将该检查升级为真实项目责任范围或受邀者已完成工作链的结论。[cite: 3f6be7d3861e3531bc265a38a21c04cf ¶0-3] <!-- c:8c19f58d -->

【forming】2026-05-10 的七条首链回放显示三种观察到的停点：有人停在来源选择，有人已放入材料但未识别留下状态的步骤，有人停在帮助页；这些只能作为可观察动作和最后画面的分类，不能把离开或失焦推断为失败原因。编号四降为原因未知，只有编号六的支持回复把停点与“不会选哪类来源”的明确困惑连起来。[cite: 300858bd809f88821ec8c6debb8f233b ¶2-5] <!-- c:3a5d7bc9 -->

【firm】2026-05-10，两条完成记录保留不同路径与状态时间：一条从单封邮件开始，另一条先放入会议摘录；一个在导入当下写状态，另一个隔天补写。它们是完成记录，不足以规定所有人的统一路线，也不能把隔天补写改写成即时动作。[cite: 300858bd809f88821ec8c6debb8f233b ¶4] [cite: 300858bd809f88821ec8c6debb8f233b ¶11] [cite: 300858bd809f88821ec8c6debb8f233b ¶14] <!-- c:dbfcc1b9 -->

【firm】一条正面留言只能先作为访谈线索：保留对方关于“把一次变更带回原话，看得明白”及是否继续整理的原话和语境，同时明确没有购买、试用、转介或提供材料的表示；不得由正面评价推出销售阶段。只有对方明确愿意讨论后，才新增访谈记录，联系本身和“最近忙”或无回复均不自动进入销售结论。[cite: 92e6885627aff6b284096547aeb63011 ¶0-8] <!-- c:11c1867b -->
