---
pneuma_id: 5f9a5c602cc3
slug: qiao-ning
type: person
---

# 乔宁

## 角色与关联
乔宁负责 Orion 试点的数据安全边界与安全评审。[cite: cb29d30c7ffded101afeb5468fa8d5ee ¶32-38] <!-- c:45f3c2fc -->

## 承诺与职责
乔宁将发送安全检查项，重点覆盖出网、隔离、日志、删除和私聊授权；他支持“十九题正确加一题明确证据不足”的验收口径。[cite: cb29d30c7ffded101afeb5468fa8d5ee ¶54-59][cite: cb29d30c7ffded101afeb5468fa8d5ee ¶97-102] <!-- c:47bfd72d -->

乔宁要求对 vault 路径和内容范围进行自动测试，并要求项目结束后的删除有可审计证明。[cite: cb29d30c7ffded101afeb5468fa8d5ee ¶41-48] <!-- c:f817ad40 -->
