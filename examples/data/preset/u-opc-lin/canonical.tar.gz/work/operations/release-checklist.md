---
pneuma_id: 2e8416fa5666
slug: release-checklist
type: operation
---

# 公开发布检查

- 发布前运行单测、生产构建和无密钥 mock 全链路。[cite: 7e133b3e779b47898445c47acf8520e7 ¶0] <!-- c:abc1a2aa -->
- 凭据只从本地环境读取，禁止进入日志、canonical 与示例数据。[cite: 7e133b3e779b47898445c47acf8520e7 ¶1] <!-- c:d2b6057e -->
- README 必须覆盖能力边界、快速开始、恢复路径和已知限制。[cite: 7e133b3e779b47898445c47acf8520e7 ¶2] <!-- c:f541d304 -->
