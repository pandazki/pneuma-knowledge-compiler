---
doc_id: e215da944f68
slug: subscription-cleanup
title: Subscription cleanup
type: operation
---

## Current state

【forming】The collaboration add-on has a cancellation request submitted, but the page still shows it as pending; until the counterparty replies, possible continued charging and any refund remain unknown, so the item stays in the draft's pending-reconciliation row and is not treated as a saving or budget decision. This record is part of the [cash-flow reconciliation](cash-flow-reconciliation.md). [cite: 5a8e41525156d6642803888d0a1c491a ¶0] <!-- c:c45803a2 -->

【forming】The separate tool is not being cancelled yet: 林舟 is checking whether any files still depend on it for opening old exports. If no dependency is found, a separate cancellation record will be opened; if a dependency remains, the tool's purpose and a next review point will be retained. [cite: 5a8e41525156d6642803888d0a1c491a ¶1] <!-- c:320b090b -->

【firm】2026-04-28，林舟把“服务要留”与“每个实例都要留”拆开：云服务最低套餐必须保留，因为试点记录和导出仍在主环境；临时测试环境当晚可关闭，数据已回到主环境。关闭前仍需由林舟核对技术删除安全性，并记录资源标识、账单周期、操作人及关闭后的结果；吴岚提供的使用范围不能替代这项技术核对。[现金流核对](cash-flow-reconciliation.md)只按拆分后的项目记录支出，不把临时环境的关闭直接写成已实现节省。[cite: 10b66a97a7e1d6e8b2f094f369dbb9f9 ¶15-18] <!-- c:a40130bb -->

【firm】临时环境关闭前，材料记录的操作者须确认资源身份、最近活动、计费周期，以及主环境中的两条试点记录仍可打开和导出；若主环境导出失败则停止关闭并保持临时环境原样，若通过则只记录关闭返回状态和账单估算变化，不把动作直接写成客户款项状态变化。该动作属于[现金流核对](cash-flow-reconciliation.md)中的可控支出处理；原材料未提供发生日，计划中的“18:30”保持原文且未确认。[cite: 48201cc671e197458adf9cf91ef7c7e5 ¶6-7] <!-- c:d0a7e2f0 -->

【forming】截图标注工具的自动续费拟关闭后，材料记录的操作者会用空白样例打开并导出一份历史标注来验证替代可行性；若导出仍要求有效订阅，则先恢复续费并将该项改为“待替代工具”，未验证的节省额不进入缓冲。测试只记录结果，不复制历史内容。[cite: 48201cc671e197458adf9cf91ef7c7e5 ¶4] [cite: 48201cc671e197458adf9cf91ef7c7e5 ¶9] <!-- c:ecf3e3bc -->
