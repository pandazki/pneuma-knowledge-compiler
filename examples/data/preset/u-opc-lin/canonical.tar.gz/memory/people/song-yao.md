---
pneuma_id: 3a2c10ffae95
slug: song-yao
type: person
---

# 宋遥

## 角色与关联
宋遥参与 Orion 交互设计，当前负责交互稿交付。[cite: 2b08df3ebdd4d1f75824a9c114980804 ¶1] <!-- c:a4ec9a94 -->

## 承诺与职责
宋遥承诺周一交付交互稿，重点展示跨来源时间线，不做复杂管理表单。[cite: 2b08df3ebdd4d1f75824a9c114980804 ¶1] <!-- c:723ee2e1 -->
